package ejeruno;

public class Principal {

	public static void main(String[] args) {
		Student std = new Student();
		System.out.println(std.stuId+std.name+std.stuStatus);
		Person prs = new Person();
	}
}
