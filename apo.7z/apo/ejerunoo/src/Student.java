package ejeruno;

public class Student {
	String name="Lisa Palombo";
	double stuId =123456789;
	String stuStatus="Active";
}
