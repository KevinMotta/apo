
public class Person {
	private String name;
	private int edad;
	
	public Person(String name, int age) {
		
		this.name = name;
		this.edad = age;
	}
	public String getName() {
		return name;
	}
	public int getEdad() {
		return edad;
	}
	public void setEdad(int edad) {
		this.edad = edad;
	}

	
}
