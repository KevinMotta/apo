package ejeruno;

public class MaginPeople {

	public static void main(String[] args) {
	
			Person p1= new Person("Arial", 37);
			Person p2= new Person("Joseph", 15);
		
			if (p1.getEdad()==p2.getEdad()) {
				System.out.println(p1.getName()+" tiene el mismo nombre que "+p2.getName());
			}
			else {
				System.out.println(p1.getName()+" NO tiene el mismo nombre que "+p2.getName());
			}
	}
}
