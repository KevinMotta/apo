package Firstpnt;

public class Main {
	public static void main(String[] args) {
		Tri area=new Tri();
		Form for = new Form();
		
	}
	}
