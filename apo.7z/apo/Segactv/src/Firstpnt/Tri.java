package Firstpnt;

import java.util.Scanner;

import javax.security.sasl.SaslClient;

public class Tri {
	Scanner ba=new Scanner(System.in);

	Scanner al=new Scanner(System.in);
	private void Cal() {
		System.out.println("Calcule el area de un triangulo."+"\n");
		float b,h,a;
		System.out.println("Ingrese el valor de la base de su triangulo");
		b=ba.nextFloat();
		System.out.println("Ingrese el valor de la altura de su triangulo");
		h=al.nextFloat();
		a = 1/2*b*h;
		
				
		
	}
		
}
