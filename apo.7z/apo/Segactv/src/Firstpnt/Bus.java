package Firstpnt;

public class Bus {

}
